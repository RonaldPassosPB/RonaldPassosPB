# 👋 Olá! Eu sou Ronald Passos Braz

🎓 Estudante de Sistemas de Informação  
💼 Estagiário de Análise de Sistemas  
📧 ronaldpassosfv@gmail.com

## 🚀 Tecnologias que domino
![Java](https://img.shields.io/badge/Java-007396?style=for-the-badge&logo=java&logoColor=white)
![Spring Boot](https://img.shields.io/badge/SpringBoot-6DB33F?style=for-the-badge&logo=spring-boot&logoColor=white)
![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)
![Oracle](https://img.shields.io/badge/Oracle-F80000?style=for-the-badge&logo=oracle&logoColor=white)
![.NET](https://img.shields.io/badge/.NET-512BD4?style=for-the-badge&logo=dotnet&logoColor=white)

## 📈 Estatísticas do GitHub
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=RonaldPassosPB&show_icons=true&theme=radical)
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=RonaldPassosPB&layout=compact&theme=radical)

## 🐍 Snake contribuindo!
![Snake animation](https://github.com/RonaldPassosPB/RonaldPassosPB/blob/output/github-contribution-grid-snake.svg)